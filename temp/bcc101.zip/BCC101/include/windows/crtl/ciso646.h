/*  cdos.h

    Standard C header file wrapper for iso646.h
*/

/*
 *      C/C++ Run Time Library - Version 24.0
 *
 *      Copyright (c) 2002, 2016 by Embarcadero Technologies, Inc.
 *      All Rights Reserved.
 *
 */

#define  __USING_CNAME__
#include <iso646.h>
#undef   __USING_CNAME__
