/*  cassert.h

    Standard C header file wrapper for assert.h
*/

/*
 *      C/C++ Run Time Library - Version 24.0
 *
 *      Copyright (c) 1997, 2016 by Embarcadero Technologies, Inc.
 *      All Rights Reserved.
 *
 */

/* $Revision: 23293 $ */

#define  __USING_CNAME__
#include <assert.h>
#ifndef __ASSERT_H_USING_LIST
# define __ASSERT_H_USING_LIST
  using std::_assert;
  using std::__assertfail;
#endif
#undef   __USING_CNAME__
