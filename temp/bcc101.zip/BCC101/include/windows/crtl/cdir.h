/*  cdir.h

    Standard C header file wrapper for dir.h
*/

/*
 *      C/C++ Run Time Library - Version 24.0
 *
 *      Copyright (c) 1997, 2016 by Embarcadero Technologies, Inc.
 *      All Rights Reserved.
 *
 */


/* $Revision: 24271 $ */

#define  __USING_CNAME__
#include <dir.h>
#undef   __USING_CNAME__
