/* Limits.h - stub redirector for _lim.h
*/

/*
 *      C/C++ Run Time Library - Version 24.0
 *
 *      Copyright (c) 2002, 2016 by Embarcadero Technologies, Inc.
 *      All Rights Reserved.
 *
 */


# include <_lim.h>
