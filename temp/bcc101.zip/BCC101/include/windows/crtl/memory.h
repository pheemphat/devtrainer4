/* Memory.h - stub redirector for either mem.h
*/

/*
 *      C/C++ Run Time Library - Version 24.0
 *
 *      Copyright (c) 2002, 2016 by Embarcadero Technologies, Inc.
 *      All Rights Reserved.
 *
 */


#include <mem.h>
