#pragma option push -b -a8 -pc -A- /*P_O_Push*/
//+---------------------------------------------------------------------------
//
//  Microsoft Windows
//  Copyright (C) Microsoft Corporation, 1992-1999.
//
//  File:       dvobj.h
//
//----------------------------------------------------------------------------

#if _MSC_VER > 1000
#pragma once
#endif

#ifndef RC_INVOKED
#pragma message("WARNING: your code should include ole2.h instead of dvobj.h")
#endif /* !RC_INVOKED */

#include <ole2.h>

#pragma option pop /*P_O_Pop*/
