/*****************************************************************************\
*                                                                             *
* DataPath.h    Obsolete DataPath header                                      *
*                                                                             *
*               Copyright 1995 - 1999 Microsoft Corp. All rights reserved.    *
*                                                                             *
\*****************************************************************************/

#ifndef __datapath_h__
#pragma option push -b -a8 -pc -A- /*P_O_Push*/
#define __datapath_h__
#pragma message("WARNING: your code should #include ocidl.h instead of datapath.h")
#include <ocidl.h>
#pragma option pop /*P_O_Pop*/
#endif
