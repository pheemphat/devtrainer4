//---------------------------------------------------------------------------
// Borland C++Builder
// Copyright (c) 1987, 2000 Borland International Inc.  All Rights Reserved.
//---------------------------------------------------------------------------

TITLE:
    STL Tests

DESCRIPTION:
    Runs miscellaneous demos of STL algorithms and types.

DEMONSTRATES:
    + The use of Standard Template Library.

COMMENTS:
    None.
        
